﻿using CommuniLend.Data.Models.Constraints;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CommuniLend.Data.Models
{
    public class OpenLoan
    {

        [Key]
        public int Id { get; set; }


        [Required]
        public required int ToolId { get; set; }

        [ForeignKey(nameof(ToolId))]
        public virtual Tool Tool { get; set; } = null!;

        [Required]
        public required int OwnerId { get; set; }


        [ForeignKey(nameof(OwnerId))]
        public virtual Member Owner { get; set; } = null!;



        [Required]
        public required int BorrowerId { get; set; }


        [ForeignKey(nameof(BorrowerId))]
        public virtual Member Borrower { get; set; } = null!;


        [Required]
        public DateOnly LoanDate { get; set; }


        [Required]
        public DateOnly DueDate { get; set; }


        [StringLength(ValidationConstants.Loan.NotesMaxLength)]
        public string? Notes { get; set; }
    }
}
